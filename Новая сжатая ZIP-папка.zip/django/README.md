# Django 6 kunlik blog loyihasi

Bu loyiha 1-6 kunlik Django darslari asosida tayyorlangan to'liq blog saytidir.

## Nimalar bor
- Bosh sahifa
- Biz haqimizda sahifasi
- Aloqa sahifasi
- Ommabop postlar sahifasi
- Post batafsil sahifasi
- Admin panel
- SQLite ma'lumotlar bazasi bilan ishlash
- Static CSS dizayn

## Ishga tushirish

### Windows
```bash
python -m venv muhit
muhit\Scriptsctivate
pip install -r requirements.txt
python manage.py migrate
python manage.py loaddata fixtures/postlar.json
python manage.py createsuperuser
python manage.py runserver
```

### Mac/Linux
```bash
python3 -m venv muhit
source muhit/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py loaddata fixtures/postlar.json
python manage.py createsuperuser
python manage.py runserver
```

So'ng brauzerda:
- http://127.0.0.1:8000/
- http://127.0.0.1:8000/admin/

## Asosiy fayllar
- `blog/models.py` - Post modeli
- `blog/views.py` - Sahifalar logikasi
- `blog/urls.py` - Blog URL manzillari
- `blog/templates/blog/` - HTML shablonlar
- `blog/static/blog/css/uslub.css` - CSS uslublar
- `fixtures/postlar.json` - Test postlar
