from django.db.models import F
from django.shortcuts import get_object_or_404, render

from .models import Post


def bosh_sahifa(request):
    postlar = Post.objects.filter(nashr_etilgan=True).order_by('-yaratilgan_sana')
    return render(request, 'blog/bosh.html', {'postlar': postlar})


def biz_haqimizda(request):
    return render(request, 'blog/biz_haqimizda.html')


def aloqa(request):
    return render(request, 'blog/aloqa.html')


def ommabop_postlar(request):
    postlar = Post.objects.filter(nashr_etilgan=True).order_by('-korildi', '-yaratilgan_sana')[:5]
    return render(request, 'blog/ommabop.html', {'postlar': postlar})


def post_batafsil(request, post_id):
    post = get_object_or_404(Post, id=post_id, nashr_etilgan=True)
    Post.objects.filter(id=post.id).update(korildi=F('korildi') + 1)
    post.refresh_from_db()
    return render(request, 'blog/post_batafsil.html', {'post': post})
