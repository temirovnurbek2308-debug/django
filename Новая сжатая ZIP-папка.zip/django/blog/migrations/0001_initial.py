from django.db import migrations, models


class Migration(migrations.Migration):
    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name='Post',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('sarlavha', models.CharField(max_length=200)),
                ('matn', models.TextField()),
                ('muallif', models.CharField(max_length=100)),
                ('yaratilgan_sana', models.DateTimeField(auto_now_add=True)),
                ('yangilangan_sana', models.DateTimeField(auto_now=True)),
                ('nashr_etilgan', models.BooleanField(default=True)),
                ('korildi', models.IntegerField(default=0)),
            ],
            options={
                'verbose_name': 'Post',
                'verbose_name_plural': 'Postlar',
                'ordering': ['-yaratilgan_sana'],
            },
        ),
    ]
