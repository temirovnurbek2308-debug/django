from django.test import TestCase
from django.urls import reverse

from .models import Post


class BlogViewsTest(TestCase):
    def setUp(self):
        self.post = Post.objects.create(
            sarlavha='Test post',
            matn='Test matn',
            muallif='Nurbek',
            nashr_etilgan=True,
        )

    def test_bosh_sahifa_ochiladi(self):
        response = self.client.get(reverse('bosh_sahifa'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'So'nggi Postlar')

    def test_post_batafsil_ko_rildi_oshadi(self):
        old = self.post.korildi
        response = self.client.get(reverse('post_batafsil', args=[self.post.id]))
        self.assertEqual(response.status_code, 200)
        self.post.refresh_from_db()
        self.assertEqual(self.post.korildi, old + 1)
