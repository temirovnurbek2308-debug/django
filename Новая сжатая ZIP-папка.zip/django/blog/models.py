from django.db import models


class Post(models.Model):
    sarlavha = models.CharField(max_length=200)
    matn = models.TextField()
    muallif = models.CharField(max_length=100)
    yaratilgan_sana = models.DateTimeField(auto_now_add=True)
    yangilangan_sana = models.DateTimeField(auto_now=True)
    nashr_etilgan = models.BooleanField(default=True)
    korildi = models.IntegerField(default=0)

    class Meta:
        ordering = ['-yaratilgan_sana']
        verbose_name = 'Post'
        verbose_name_plural = 'Postlar'

    def __str__(self):
        return self.sarlavha
