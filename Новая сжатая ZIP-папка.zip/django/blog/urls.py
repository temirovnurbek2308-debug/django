from django.urls import path
from . import views

urlpatterns = [
    path('', views.bosh_sahifa, name='bosh_sahifa'),
    path('biz-haqimizda/', views.biz_haqimizda, name='biz_haqimizda'),
    path('aloqa/', views.aloqa, name='aloqa'),
    path('ommabop/', views.ommabop_postlar, name='ommabop'),
    path('post/<int:post_id>/', views.post_batafsil, name='post_batafsil'),
]
